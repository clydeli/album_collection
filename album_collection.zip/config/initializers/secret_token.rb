# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AlbumCollection::Application.config.secret_token = 'f77950a512b2b79ad56c5a80353548d2d393eb18efd040fab2aaba170ea5ed76e42f77ae47883adeb726023da35df1540e1fa900ecd7fa4fda6c9881e40a9cf5'
