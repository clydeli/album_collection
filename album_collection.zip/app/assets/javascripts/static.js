/**
 * Created with JetBrains RubyMine.
 * User: clydeli
 * Date: 9/18/12
 * Time: 10:56 AM
 * To change this template use File | Settings | File Templates.
 */
/*$(document).ready(function(){
    $('p').hide();

});*/