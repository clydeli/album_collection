module AlbumHelper
end
