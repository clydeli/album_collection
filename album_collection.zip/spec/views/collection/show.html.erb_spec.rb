require 'spec_helper'

describe "collection/show.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
